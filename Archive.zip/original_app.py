from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
import json
import logging
import sys
import os
import time
from datetime import datetime

# Import the RAG assistant
try:
    from original_rag_assistant import FlaskRAGAssistant
except ImportError:
    FlaskRAGAssistant = None

# Import the PromptEvaluator and evaluation parser
from evaluator import PromptEvaluator
from evaluation_parser import parse_evaluation

from config import *

# Configure logging
logger = logging.getLogger(__name__)
if logger.handlers:
    logger.handlers.clear()

file_handler = logging.FileHandler('app.log')
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

stream_handler = logging.StreamHandler(sys.stdout)
stream_handler.setFormatter(formatter)
logger.addHandler(stream_handler)
logger.setLevel(logging.DEBUG)

logger.info("RAG Assistant Interface starting up")

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Initialize RAG assistant
try:
    if FlaskRAGAssistant:
        rag_assistant = FlaskRAGAssistant()
        logger.info("RAG Assistant initialized successfully")
    else:
        rag_assistant = None
        logger.warning("FlaskRAGAssistant not available")
except Exception as e:
    logger.error(f"Failed to initialize RAG Assistant: {e}")

@app.route('/')
def index():
    """Serve the main interface"""
    return render_template('index.html')

@app.route('/api/system_prompt', methods=['GET'])
def system_prompt():
    """Return the default system prompt"""
    return jsonify({'system_prompt': rag_assistant.system_prompt if rag_assistant else ''})

@app.route('/api/query', methods=['POST'])
def query():
    """Handle query requests from the interface"""
    try:
        data = request.get_json()
        
        if not data or 'query' not in data:
            return jsonify({'error': 'Query is required'}), 400
        
        query_text = data['query']
        model = data.get('model', 'gpt-4o')
        appended_prompt = data.get('appended_prompt', '')
        temperature = data.get('temperature', 0.7)
        top_k = data.get('top_k', 50)
        top_p = data.get('top_p', 0.9)
        max_tokens = data.get('max_tokens', 1000)
        
        logger.info(f"Processing query: {query_text[:100]}...")
        logger.info(f"Parameters - Model: {model}, Temp: {temperature}, Top-K: {top_k}, Top-P: {top_p}")
        logger.info(f"Appended Prompt: {appended_prompt}")
        logger.info("System Prompt: %s", rag_assistant.system_prompt)
        logger.info("Original Query Text: %s", query_text)
        logger.info("Full System Prompt Used: %s", rag_assistant.system_prompt + ("\n" + appended_prompt if appended_prompt else ""))
        
        start_time = time.time()
        
        # Real mode - use RAG assistant
        if not rag_assistant:
            return jsonify({'error': 'RAG Assistant not available. Please check your Azure configuration.'}), 500
        
        # Call the RAG assistant
        params = {
            'query': query_text,
            'deployment': model,
            'max_tokens': max_tokens,
            'appended_prompt': appended_prompt
        }
        if model not in ('o3', 'o4-mini'):
            params['temperature'] = temperature
            params['top_p'] = top_p
        result = rag_assistant.query(**params)
        
        end_time = time.time()
        response_time = int((end_time - start_time) * 1000)  # Convert to milliseconds
        
        # Extract answer and sources from result
        if isinstance(result, tuple) and len(result) >= 2:
            answer, sources = result[0], result[1]
        else:
            answer = str(result)
            sources = []
        
        # Format sources for display
        formatted_sources = []
        if sources:
            for i, source in enumerate(sources[:5]):  # Limit to 5 sources
                if isinstance(source, dict):
                    formatted_sources.append({
                        'title': source.get('title', f'Source {i+1}'),
                        'content': source.get('content', '')[:200] + '...' if len(source.get('content', '')) > 200 else source.get('content', ''),
                        'score': source.get('score', 0)
                    })
                else:
                    formatted_sources.append({
                        'title': f'Source {i+1}',
                        'content': str(source)[:200] + '...' if len(str(source)) > 200 else str(source),
                        'score': 0
                    })
        
        logger.info(f"Answer: {answer}")
        logger.info(f"Sources count: {len(formatted_sources)}")
        logger.info("Context: %s", formatted_sources)
        logger.info(f"Max tokens: {max_tokens}, Top-P: {top_p}, Top-K: {top_k}")
        logger.info(f"Response time: {response_time}ms")
        logger.info("Token Count: %d", len(answer.split()) if answer else 0)
        response_data = {
            'answer': answer,
            'sources': formatted_sources,
            'model': model,
            'temperature': temperature,
            'top_k': top_k,
            'top_p': top_p,
            'max_tokens': max_tokens,
            'response_time': response_time,
            'token_count': len(answer.split()) if answer else 0,  # Rough token estimate
            'status': 'success',
            'timestamp': datetime.now().isoformat()
        }
        
        logger.info(f"Query processed successfully in {response_time}ms")
        return jsonify(response_data)
        
    except Exception as e:
        logger.error(f"Error processing query: {e}")
        return jsonify({
            'error': str(e),
            'status': 'error',
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/evaluate', methods=['POST'])
def evaluate():
    """Handle evaluation requests"""
    try:
        # Log the raw request data for debugging
        raw_data = request.get_data(as_text=True)
        logger.info(f"Raw evaluation request data: {raw_data}")
        
        data = request.get_json()
        logger.info(f"Parsed evaluation request data: {json.dumps(data, indent=2)}")
        
        if not data or 'query' not in data or 'answer' not in data:
            logger.error(f"Missing required fields in request: {data.keys() if data else 'No data'}")
            return jsonify({'error': 'Query and answer are required'}), 400
        
        # Extract the required variables for the evaluator
        user_query = data['query']
        bot_response = data['answer']
        
        # Process the context data
        sources = data.get('sources', [])
        context_str = ""
        
        # If we have sources, format them as a string
        if sources:
            logger.info(f"Processing {len(sources)} sources")
            for i, source in enumerate(sources):
                if isinstance(source, dict):
                    content = source.get('content', '')
                    title = source.get('title', f'Source {i+1}')
                    context_str += f"{title}: {content}\n\n"
                else:
                    context_str += f"Source {i+1}: {str(source)}\n\n"
        else:
            # If no sources, use the context field if available
            context_str = data.get('context', '')
            logger.info(f"No sources found, using context field: {len(context_str)} chars")
            
        # Get the system prompt used (bot instructions)
        bot_instructions = rag_assistant.system_prompt if rag_assistant else ""
        appended_prompt = data.get('appended_prompt', '')
        if appended_prompt:
            bot_instructions += "\n" + appended_prompt
            
        # Store these variables for logging and debugging
        evaluation_data = {
            "User_Query": user_query,
            "Retrieved_Context": context_str,
            "Bot_Response": bot_response,
            "Bot_Instructions": bot_instructions
        }
        
        # Log the evaluation data for debugging
        logger.info("Evaluation Data:")
        for key, value in evaluation_data.items():
            logger.info(f"- {key}: {value[:100]}..." if len(value) > 100 else f"- {key}: {value}")
        
        logger.info(f"Evaluating response for query: {user_query[:100]}...")
        logger.info(f"Context length: {len(context_str)} characters")
        logger.info(f"Bot response length: {len(bot_response)} characters")
        logger.info(f"Bot instructions length: {len(bot_instructions)} characters")
        
        try:
            # Initialize the PromptEvaluator and perform evaluation
            logger.info("Initializing PromptEvaluator...")
            evaluator = PromptEvaluator()
            
            # Log the parameters being passed to the evaluator
            logger.info("Calling evaluator.evaluate with parameters:")
            logger.info(f"- user_query: {user_query[:100]}...")
            logger.info(f"- retrieved_context: {context_str[:100]}...")
            logger.info(f"- bot_response: {bot_response[:100]}...")
            logger.info(f"- bot_instructions: {bot_instructions[:100]}...")
            
            evaluation_text = evaluator.evaluate(
                user_query=user_query,
                retrieved_context=context_str,
                bot_response=bot_response,
                bot_instructions=bot_instructions
            )
            
            logger.info(f"Evaluation completed successfully: {evaluation_text[:100]}...")
            
            # Parse the evaluation text to extract structured metrics
            logger.info("Parsing evaluation text to extract structured metrics...")
            parsed_evaluation = parse_evaluation(evaluation_text)
            
            logger.info(f"Parsed evaluation metrics: {parsed_evaluation['metrics']}")
            
            # Return both the structured metrics and the full evaluation text
            return jsonify({
                "evaluation": evaluation_text,
                "metrics": parsed_evaluation["metrics"],
                "full_evaluation": parsed_evaluation["full_evaluation"]
            })
        except Exception as eval_error:
            logger.error(f"Evaluation engine error: {eval_error}")
            import traceback
            logger.error(f"Traceback: {traceback.format_exc()}")
            return jsonify({
                'error': f"Evaluation engine error: {str(eval_error)}",
                'status': 'error',
                'timestamp': datetime.now().isoformat()
            }), 500
        
    except Exception as e:
        logger.error(f"Error during evaluation request processing: {e}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({
            'error': str(e),
            'status': 'error',
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/export', methods=['POST'])
def export_session():
    """Export session data as markdown"""
    try:
        data = request.get_json()
        logger.info("Received export request")
        
        # Extract session data
        query = data.get('query', '')
        system_prompt = data.get('system_prompt', '')
        appended_prompt = data.get('appended_prompt', '')
        model = data.get('model', '')
        temperature = data.get('temperature', '')
        top_k = data.get('top_k', '')
        top_p = data.get('top_p', '')
        answer = data.get('answer', '')
        sources = data.get('sources', [])
        evaluation = data.get('evaluation', {})
        
        # Format the markdown content
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        md_content = f"""# RAG Assistant Session Export

## Session Information
- **Timestamp**: {timestamp}
- **Model**: {model}

## Query
```
{query}
```

## System Prompt
```
{system_prompt}
```

## Appended Prompt
```
{appended_prompt}
```

## Model Parameters
- **Temperature**: {temperature}
- **Top K**: {top_k}
- **Top P**: {top_p}

## Response
```
{answer}
```

## Sources
"""
        
        # Add sources
        if sources:
            for i, source in enumerate(sources):
                title = source.get('title', f'Source {i+1}')
                content = source.get('content', '')
                md_content += f"""
### {title}
```
{content}
```
"""
        else:
            md_content += "\nNo sources available.\n"
        
        # Add evaluation metrics
        md_content += "\n## Evaluation Metrics\n"
        
        metrics = evaluation.get('metrics', {})
        if metrics:
            md_content += f"""
- **Overall Score**: {metrics.get('overall_score', 'N/A')}
- **Relevance**: {metrics.get('relevance', 'N/A')}
- **Accuracy**: {metrics.get('accuracy', 'N/A')}
- **Completeness**: {metrics.get('completeness', 'N/A')}
- **Clarity**: {metrics.get('clarity', 'N/A')}
- **Question Understood**: {metrics.get('question_understood', 'N/A')}
- **Response Type**: {metrics.get('response_type', 'N/A')}
- **Effectiveness**: {metrics.get('effectiveness', 'N/A')}
- **Factually Correct**: {metrics.get('factually_correct', 'N/A')}
- **Engagement**: {metrics.get('engagement', 'N/A')}
- **Confidence**: {metrics.get('confidence', 'N/A')}
- **Context Usage**: {metrics.get('context_usage', 'N/A')}
"""
        else:
            md_content += "\nNo evaluation metrics available.\n"
        
        # Add detailed analysis
        detailed_analysis = metrics.get('detailed_analysis', '')
        if detailed_analysis:
            md_content += f"""
## Detailed Analysis
{detailed_analysis}
"""
        
        # Add suggestions
        suggestions = metrics.get('suggestions', '')
        if suggestions:
            md_content += f"""
## Suggestions
{suggestions}
"""
        
        # Add full evaluation
        full_evaluation = evaluation.get('full_evaluation', '')
        if full_evaluation:
            md_content += f"""
## Full Evaluation
{full_evaluation}
"""
        
        logger.info(f"Generated markdown export with {len(md_content)} characters")
        
        return jsonify({
            'markdown': md_content,
            'filename': f"rag-session-{datetime.now().strftime('%Y%m%d-%H%M%S')}.md",
            'status': 'success'
        })
        
    except Exception as e:
        logger.error(f"Error exporting session: {e}")
        return jsonify({
            'error': str(e),
            'status': 'error'
        }), 500

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'rag_assistant': 'available' if rag_assistant else 'unavailable',
        'timestamp': datetime.now().isoformat()
    })

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    # Use a different port (5006) to avoid conflicts
    port = 5006
    debug = os.environ.get('FLASK_DEBUG', 'True').lower() == 'true'
    
    logger.info(f"Starting Flask app on port {port} with debug={debug}")
    
    app.run(host='0.0.0.0', port=port, debug=debug)
